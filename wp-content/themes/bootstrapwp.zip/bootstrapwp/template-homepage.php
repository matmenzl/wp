<?php
/**
 * 
 *Template Name: Homepage
 *
 * The template for displaying the left sidebar page.
 *
 * @package bootstrapwp
 */

get_header(); ?>

<div class="container">
<div class="row">

	<div class="jumbotron">
        <h1>Titel</h1>
        <p>Beispiel einer statischen Homepage</p>
        <p>
          <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">Link zu wichtiger Unterseite»</a>
        </p>
      </div>

</div>
</div>

<?php get_footer(); ?>
